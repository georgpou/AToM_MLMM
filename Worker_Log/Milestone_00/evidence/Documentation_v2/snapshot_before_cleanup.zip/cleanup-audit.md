# AToM_MLMM: repository and agent-context audit

**Reviewed:** 29 September 2026.  
**Basis:** the supplied `AToM_MLMM.zip`, not an assumed copy of the live website.  
**Git HEAD in that snapshot:** `e662a442641367f8056d0254166b49c4803f1f7c`.  
**ZIP SHA-256:** `475c47d99e05ea3acf230ba13f28a640a8ee188c7c74c2c3e89a971630778301`.  
**Scope:** identify unnecessary files, duplicate documentation authorities, excessive agent reading, and a safe consolidation route. No repository source/documentation files were deleted or rewritten. No molecular packages were installed and no numerical scientific qualification was attempted.

## 1. Conclusion

The repository has too much **procedural scaffolding**, not simply too much scientific explanation. It repeatedly explains how to find work, how to perform a small task, how to write a log, and how not to overclaim a result. Meanwhile, the same planned tests and progress information appear in several maintained representations.

Keep the scientific gate definitions, their acceptance tests, the shared scientific/interface specifications, and actual worker/audit evidence. Consolidate the navigation and workflow rules. Retire duplicate live indexes and old delivery instructions. Do not solve the problem by putting every document into one enormous file or deleting the scientific detail reviewers need.

The recommended structure has approximately **31 active Markdown pages**, rather than 77 Markdown files mixed across live instructions, reference, history and reports. It also retains the Conda YAML, the two historical plans, and the existing worker report/evidence. The reduction is a proposal, not an applied cleanup. The more important target is that a worker opens **one global instruction file, the assigned task, and only the relevant scientific sections and prior findings**.

### What is actually present

| Observation | Measured result |
|---|---:|
| Project files, excluding `.git`, Finder metadata and Apple resource forks | 84 |
| Markdown files | 77 |
| Words across those Markdown files | 79,560 |
| Words in the two historical plans | 25,955 |
| Words in the remaining Markdown | 53,605 |
| Gate pages / smaller named tasks | 14 / 42 |
| Shared specifications / requirement IDs | 7 / 32 |
| Planned test IDs | 82 |
| Actual submitted worker logs / audit logs | 1 / 0 |
| Implemented application package, scientific test suite, or CI workflow | None present |
| Python source file present | The historical documentation checker only |

Words were counted by whitespace splitting of complete Markdown, including tables and code blocks; these are not token counts. The 79,560-word total is **not** a claim that every agent currently must read all of it. The current instructions already say to read selectively. The problem is that even the selective route still leads through overlapping documents.

## 2. Highest-value changes

### A. Make one entry point, not a chain of indexes

There is no root `README.md` in this snapshot. Instead, `PROJECT_PLAN.md`, `docs/README.md`, `docs/project-0/README.md`, and the indexes inside `gates/`, `milestones/`, `specs/` and `decisions/` repeatedly introduce and link the same structure.

Reuse the useful material as **one root README**: a short project description, the milestone/gate/dependency/log-folder table, and links to environment setup, status and scientific references. A worker already assigned `G01-T1` should bypass that table and go straight to G01. Preserve the distinction between gate dependencies and milestone combined reviews.

This does not mean a README is inherently unnecessary. It means this repository does not need several intermediary pages before reaching a task.

**Evidence:** `PROJECT_PLAN.md:3-9`; `docs/README.md:7-30`; `docs/project-0/README.md:13-39`.

### B. Put agent procedure in one place

`AGENTS.md` is 1,328 words. `Worker_Log/README.md` is another 1,528. The test-first guide, assignment guide, gate text, milestone text, and templates restate portions of both.

Keep a shorter `AGENTS.md` as the global rulebook. Preserve the hard scientific prohibitions, one-task scope, exact snapshot requirements, real versus unrun evidence, worker/auditor independence, attempt numbering and immutable submitted logs. Keep a worker template and an audit template, with no extra report required for a routine task.

The other logging guide can then be retired after its nonduplicated rules are incorporated. Preserve the user's required model label, exposed reasoning setting, reference documents, completion time and work description. Also preserve the snapshot, actual checks, open findings and next action that make the log useful to the next agent. Do not force an agent to fill numerous empty tables for a small task.

A suggested editing budget is roughly 500-700 words for the global instructions and a few hundred words for an ordinary small-task report. These are usability targets, not limits that override necessary evidence.

**Evidence:** `AGENTS.md:37-71`; `Worker_Log/README.md:46-102`; `guides/spec-and-test-workflow.md:7-15`; the worker/audit templates. All paths abbreviated under `docs/project-0/` refer to that directory.

### C. Keep all 14 gate files, but remove repeated procedure

The gate pages contain useful, task-specific technical work. They are not the first files to delete. Together, the 14 pages contain 19,456 words. Ten identical guidance paragraphs repeated across all 14 account for **5,213 redundant word occurrences beyond keeping one copy**. A broader exact-paragraph comparison finds 5,258, including an additional repeated milestone header.

Examples include the definition of a contract/profile, the reminder that paths are only planned, generic test-first instructions, generic small-task scope, attempt-number rules and the repeated status/index synchronization paragraph. Keep their necessary rules once in `AGENTS.md`; retain only each gate's actual log folder and task stem locally.

Each gate should retain its purpose, prerequisites, concrete task IDs, inputs/outputs, exact relevant specification sections, independent expected assertions, applicable tolerances or links, execution commands, failure conditions, and log destination. Do not remove the source/test paths or pretend the 82 specified tests have already been implemented.

The existing G01 **Read for this task** section names seven other files before the optional glossary and prior work records. It points to precise sections in some of them, which is helpful, but the same reading table serves all three different tasks. Give **G01-T1, T2 and T3 their own minimal reading scopes**. Identity/selection work should not require the full future artifact/qualification schema merely because it shares a gate with schema development.

**Evidence:** `gates/G01-identity-partition-and-contracts.md:15-35,47-94,97-124`, compared with the same sections of G00-G13. The duplicate count excludes historical plans and other folders.

### D. Keep the specifications; do not merge away scientific clarity

S01-S07 separate scope, ownership, shared records, embedding, thermodynamics, validation and stored evidence. Those are different subjects. Their combined content is approximately 7,600 words, much less than the total documentation and substantially more useful than repeated procedural explanations.

Keep them as reference documents read by section. Remove repeated document-status boilerplate and general work instructions only when the controlling version/status remains available. S04's cap derivatives and periodic accounting, S05's thermodynamic signs/corrections, and S06's numerical acceptance definitions should not be cut for cosmetic brevity.

The small early two-mobile-group and environment-force tests also have a stated architectural purpose. Do not remove them in a documentation cleanup or imply they qualify actual electrostatic embedding. The current instructions explicitly require those boundaries while rejecting speculative future backend classes.

**Evidence:** S01:19-41; S02:15-43; S03:15-25,81-97; S04:19-85; S05:23-91; S06; `AGENTS.md:21-35`.

### E. Stop maintaining three planned-test representations and two progress summaries

Every one of the **82 planned pytest node IDs** appears in its gate, in `TEST_CATALOG.md`, and in `plan-index.json`. The JSON also repeats requirements, dependencies, task metadata and status. It has **2,385 lines**. The only executable consumer found in the supplied project files is the historical `check_docs.py`; no application, scheduler or CI consumer is present.

Recommendation: make gate-local acceptance tables the authority for planned test behavior, retain a compact `REQUIREMENTS.md` as an optional ID/spec/gate locator, and make `STATUS.md` the single live progress summary linked to evidence. Retire `TEST_CATALOG.md` and the live JSON mirror after updating their consumers and references. Keep all 32 requirement IDs, 42 task IDs and 82 test IDs stable during this change.

A machine-readable file is not inherently wasteful. It becomes worthwhile when real automation consumes it and other views are generated from it. That benefit is not established in this snapshot. Confirm that no external tooling outside the supplied repository depends on it before removal. Do not build a new generator merely to justify retaining duplicate views now.

This recommendation concerns the **documentation planning index**, not the future simulation manifests, schemas or raw numerical records required by S03/S07.

**Evidence:** `TEST_CATALOG.md`; `plan-index.json` fields `gates`, `milestones`, `requirements`, `tests`, `execution_records`; `STATUS.md:9,51-57`; S07:85; `check_docs.py:73,107-179`. A search through every non-metadata project file found the historical checker as its sole executable reader.

### F. Preserve milestone meaning without nine separate milestone essays

Retain M00 as a short, scoped design-review checklist while its decisions are proposed. Do not treat this audit or a documentation rearrangement as design approval.

For M01-M08, keep their IDs and grouping in the root roadmap, but move genuinely distinct combined-review checks into the final constituent gate:

| Milestone | Closing review home |
|---|---|
| M01 | G01, combining G00/G01 |
| M02 | G03, combining G02/G03 |
| M03 | G07, combining G04-G07 |
| M04 | G08 |
| M05 | G10, combining G09/G10 |
| M06 | G11 |
| M07 | G12 |
| M08 | G13 |

M04, M06, M07 and M08 each contain only one gate, making separate mandatory reviews particularly repetitive. For multi-gate milestones, preserve the requirement that components work together in the same reviewed snapshot. One audit may cover both the closing gate and its combined milestone check when its scope and evidence explicitly do so; do not infer milestone acceptance from a small accepted task.

Keep the required `Worker_Log/Milestone_XX/` organization. Its nine README placeholders are unnecessary once the roadmap and gates identify the folders. Empty folders can be created when the first log is written; deleting a placeholder must never delete actual reports or evidence.

**Evidence:** `docs/project-0/README.md:15-27`; all milestone **Combined review** sections; nine `Worker_Log/Milestone_XX/README.md` files.

### G. Consolidate environment instructions and fix actual path drift

Keep `ATM_MLMM_environment.yml`: it is the real Conda specification. Keep one environment guide, preferably `ATM_MLMM_Environment.md`, and merge the relevant warnings from `reference/environment.md`. The latter currently gives a separate venv/pip recipe, while the root guide and YAML give a Conda route. The user's chosen setup method should have one clear entry point.

Three naming problems are observable without installing anything:

- The root guide identifies and tells the user to create/update from `Project_0_ATM_MLMM_environment.yml`, but the actual filename is `ATM_MLMM_environment.yml`.
- The YAML comments point to `ENVIRONMENT.md`, which does not exist.
- The root guide links to `Project_0_ATM_MLMM_Design_and_Validation_Plan.md#L74`, which does not exist at that path.

After consolidation, the root-level creation command should point to the existing file: `conda env create -f ATM_MLMM_environment.yml`. This is a filename correction, **not** a claim that the specified package set has been solved or installed. Version/build availability, CPU/GPU selection and checkpoint compatibility remain G00 qualification work. No upstream release or package-channel audit was performed here.

**Evidence:** `ATM_MLMM_Environment.md:3,24,168,175`; `ATM_MLMM_environment.yml:12,60`; `reference/environment.md:22-40`.

### H. Retire delivery paperwork; keep historical evidence

`PROVENANCE.md`, `DOCUMENTATION_QA.md`, `reference/coverage-map.md`, `guides/documentation-maintenance.md`, and `guides/repository-integration.md` describe previous documentation editions, a completed editing assignment and a particular ZIP/patch delivery. They need not remain active implementation instructions.

Their content must remain retrievable with the old report. The submitted `Documentation_v1_worker.md` and all five files in its evidence folder should remain unchanged. The two historical plans are distinct generations, not identical copies; keep them as optional historical reference rather than current instructions.

The two short ADR files preserve useful alternatives and rationale, but currently duplicate proposed decisions in S02-S05. Fold that rationale and its **proposed** status into the owning specification before retiring the extra pages. Do not silently turn a proposal into an approved decision.

`reference/scientific-notes.md` is not empty bureaucracy. Before retiring it, move its unique free-energy correction equation and overlap warning into S04, its model-data cautions into S04/G05, and its throughput equations and Project-1 handover into G13. Likewise, move the numeric environment-force example from the workflow guide into G02/S04. These are explicit content-preservation requirements.

## 3. Verification performed and its limits

The submitted historical manifest lists 80 files, excluding itself. **All 80 still match their recorded SHA-256 values in the supplied snapshot.** This supports preserving the old report as history; a later failure does not establish that its original QA claim was false.

Running the existing checker on the current extracted project:

```text
python Worker_Log/Milestone_00/evidence/Documentation_v1/check_docs.py --self-test
Exit code: 1
Error: ATM_MLMM_Environment.md: missing target:
       ./Project_0_ATM_MLMM_Design_and_Validation_Plan.md#L74
Counts: 77 Markdown files; 826 internal link occurrences;
        14 gates; 9 milestones; 7 specifications; 42 tasks;
        32 requirements; 82 planned tests.
```

In a disposable copy only, changing that one link to the existing historical plan's scope heading made the checker return **0**, with all five deliberate-error cases detected and no baseline errors. This isolates the current failure to the added guide's stale link under the checker's implemented rules. It does not validate the guide's package claims or its backticked shell-command filenames.

In that repaired disposable copy, simply creating an empty `src/` made the checker return **1** with `unexpected molecular source/test implementation`. Its code also requires all gates to be `not_started`, all tests `not_run`, and no audit files. This behavior is intentional for a historical unexecuted documentation delivery, but unsuitable for ongoing development.

Keep that checker with the old evidence. When ongoing checking is needed, reuse only relevant structural/link/ID/dependency checks in a small current checker that permits real progress and does not freeze obsolete file paths. Do not edit the old checker or old saved output to make a changed repository look like the original delivery.

The audit did not run scientific tests because none are implemented in the snapshot. It did not verify the live GitHub tree against the ZIP. All proposed removals assume this supplied snapshot and the absence of unshown external consumers.

## 4. Minimal reading contracts

### Worker assigned G01-T1

Read `AGENTS.md`, the G01-T1 subsection with its prerequisites and relevant acceptance rows, and the named scientific sections needed for that task. In this example those are the identity/units/real-atom mapping definitions in S03 and, when implementing partition rejection, the boundary policy in S04. Inspect the relevant current status and prior worker/audit findings. Read the worker template when writing the report.

Do not require the entire roadmap, every milestone, the whole test catalog/index, all source papers, the historical plans, future-embedding guidance, or the auditor's template. The exact chemical policy still has to be read; brevity is not permission to guess it.

### Auditor

Read `AGENTS.md`, the specific worker log, its recorded snapshot/diff, the assigned task's acceptance rows and the relevant specification sections. Inspect and rerun the pertinent code/tests. Read previous unresolved findings that affect the scope. Use the audit template to record actionable findings and their closure conditions.

An audit cannot be reduced to trusting the worker's summary. Conversely, it does not require rereading every accepted unrelated gate. A repair worker reads the corresponding prior worker/audit pair and preserves the existing accepted implementation.

### One owner per kind of information

| Information | Proposed maintained home |
|---|---|
| Global behavior, role boundaries and log convention | AGENTS.md |
| Navigation and milestone/gate mapping | Root README.md |
| Shared scientific and interface meaning | S01-S07 |
| Task scope and planned acceptance assertions | The assigned gate |
| Compact requirement-ID lookup | REQUIREMENTS.md, optional lookup |
| Current progress, profile limits and unresolved findings | STATUS.md, linked to evidence |
| What a worker actually did | Its immutable worker log and evidence |
| Independent findings and accepted scope | The matching audit log |
| Environment usage | One environment guide plus the actual YAML |
| Historical wording and old delivery evidence | Recorded historical snapshot, original plans and existing evidence |

A short safety reminder next to a risky operation can be useful even when its full rule exists elsewhere. The target is duplicated authority and repeated essays, not a ban on every repeated sentence.

## 5. Proposed live structure

```text
README.md                         # consolidated entry point
AGENTS.md                         # global rules and role/log convention
ATM_MLMM_environment.yml
ATM_MLMM_Environment.md            # sole environment guide

docs/project-0/
  STATUS.md
  REQUIREMENTS.md                  # compact optional locator
  gates/G00-...md through G13-...md
  specs/S01-...md through S07-...md
  milestones/M00-architecture-review.md
  reference/sources.md
  reference/glossary.md
  templates/worker-log.md
  templates/audit-log.md

Worker_Log/
  Milestone_XX/                   # actual worker/audit logs; create as needed
    Gate_YY_vN_worker.md
    Gate_YY_vN_audit.md
    evidence/...
```

The two historical plans and existing documentation evidence remain retained but are not part of the default reading route. Do not create empty `src/`, tests, model, plugin, or future-embedding folders merely to make this diagram look more complete; implementation tasks create files when needed.

## 6. Safe cleanup order

1. Record the pre-cleanup commit above in the new cleanup handoff. Preserve the old report/evidence and verify the historical snapshot remains recoverable. For transfers without Git history, retain one immutable source archive instead of copying obsolete documents into the live reading tree.
2. Consolidate global rules, navigation and environment guidance. Move unique scientific notes, numeric examples, proposed-decision rationale and combined-review conditions into their specified owners before removing anything.
3. Retire the duplicate live JSON/catalog and update current gate, status, specification and instruction references atomically. Preserve IDs, prerequisite meaning, numerical thresholds, equations and the worker/auditor naming scheme. Check external consumers before removing the JSON.
4. Remove redundant navigation and placeholder READMEs. Preserve real milestone log directories and every existing report/evidence file. Retired document links inside immutable old reports are interpreted against their recorded historical snapshot; do not rewrite the report or demand that old paths remain live forever. Record that resolution rule in the new cleanup handoff and distinguish historical from live-link checking.
5. Remove the operating-system metadata described below and add a small `.gitignore`. Do not remove `.git` from the working clone.
6. Verify live links, unique task/requirement/test definitions, preserved scientific content, log destinations, and the ability to trace both a new task and an audit without unnecessary navigation. Do not count a green documentation checker as scientific qualification.

This cleanup should be one bounded documentation change, not another package of additional workflow guides. No architecture redesign, model change, dependency installation or gate-status promotion is needed to perform it.

## 7. File-by-file disposition

Actions are recommendations, not changes already made. A retirement requires the relinking/content-preservation steps above. The table covers all 84 non-metadata project files; Git/Finder/resource-fork files are handled separately afterward. File sizes and word counts can be reproduced from the supplied archive.


### Root and historical plan

| Current file | Action | Destination and reason |
|---|---|---|
| `AGENTS.md` | Keep; shorten | **Same path**. One global operating contract. Keep scope, hard invariants, test/evidence honesty, role rules and log naming once; absorb indispensable Worker_Log rules. |
| `ATM_MLMM_Environment.md` | Keep; consolidate | **Same path**. Make this the sole environment explanation; merge the focused reference/environment.md warnings, fix filenames, trim repeated roadmap/theory and alternative layout advice. |
| `ATM_MLMM_environment.yml` | Keep; correct references | **Same path**. The actual Conda input, not redundant prose. Fix references to nonexistent ENVIRONMENT.md. Installation/build suitability remains G00 work. |
| `Original_planning_docs/Project_0_ATM_MLMM_Implementation_and_Validation_Plan_crude.md` | Keep as history | **Same path initially**. Different historical generations, not byte-identical duplicates. Exclude from routine required reading; preserve source identity and superseded status. |
| `PROJECT_PLAN.md` | Merge; retire old path | **Root README.md**. Currently a navigation stub. Reuse it with the useful documentation-map and roadmap content as the single entry point. |

### Existing worker history and navigation

| Current file | Action | Destination and reason |
|---|---|---|
| `Worker_Log/Milestone_00/Documentation_v1_worker.md` | Keep unchanged | **Same path**. Actual submitted work report. The audit confirmed all 80 listed historical file hashes still match; do not rewrite its past outcome. |
| `Worker_Log/Milestone_00/README.md` | Remove after relinking | **Gate log destination + root roadmap**. Placeholder/navigation boilerplate, not actual work evidence. Preserve the milestone directory convention and all real logs; create empty folders on demand. |
| `Worker_Log/Milestone_00/evidence/Documentation_v1/baseline-summary.json` | Keep as historical evidence | **Same path**. Source baseline and equation/requirement/test evidence for the submitted report; not routine agent input. |
| `Worker_Log/Milestone_00/evidence/Documentation_v1/check-output.json` | Keep as historical evidence | **Same path**. Past observed result, not current working-tree status. Preserve unchanged. |
| `Worker_Log/Milestone_00/evidence/Documentation_v1/check_docs.py` | Keep as historical evidence | **Same path**. An edition-specific historical verifier, not an ongoing project acceptance check. Keep with its snapshot; do not require it to pass against future implemented code. |
| `Worker_Log/Milestone_00/evidence/Documentation_v1/draft-metadata-check.json` | Keep as historical evidence | **Same path**. Small historical negative-test output. Optional for future reading, but no benefit in pruning evidence from the existing report. |
| `Worker_Log/Milestone_00/evidence/Documentation_v1/file-manifest.sha256` | Keep as historical evidence | **Same path**. Identifies the original delivered bytes. Preserve; never refresh it to describe a different result. |
| `Worker_Log/Milestone_01/README.md` | Remove after relinking | **Gate log destination + root roadmap**. Placeholder/navigation boilerplate, not actual work evidence. Preserve the milestone directory convention and all real logs; create empty folders on demand. |
| `Worker_Log/Milestone_02/README.md` | Remove after relinking | **Gate log destination + root roadmap**. Placeholder/navigation boilerplate, not actual work evidence. Preserve the milestone directory convention and all real logs; create empty folders on demand. |
| `Worker_Log/Milestone_03/README.md` | Remove after relinking | **Gate log destination + root roadmap**. Placeholder/navigation boilerplate, not actual work evidence. Preserve the milestone directory convention and all real logs; create empty folders on demand. |
| `Worker_Log/Milestone_04/README.md` | Remove after relinking | **Gate log destination + root roadmap**. Placeholder/navigation boilerplate, not actual work evidence. Preserve the milestone directory convention and all real logs; create empty folders on demand. |
| `Worker_Log/Milestone_05/README.md` | Remove after relinking | **Gate log destination + root roadmap**. Placeholder/navigation boilerplate, not actual work evidence. Preserve the milestone directory convention and all real logs; create empty folders on demand. |
| `Worker_Log/Milestone_06/README.md` | Remove after relinking | **Gate log destination + root roadmap**. Placeholder/navigation boilerplate, not actual work evidence. Preserve the milestone directory convention and all real logs; create empty folders on demand. |
| `Worker_Log/Milestone_07/README.md` | Remove after relinking | **Gate log destination + root roadmap**. Placeholder/navigation boilerplate, not actual work evidence. Preserve the milestone directory convention and all real logs; create empty folders on demand. |
| `Worker_Log/Milestone_08/README.md` | Remove after relinking | **Gate log destination + root roadmap**. Placeholder/navigation boilerplate, not actual work evidence. Preserve the milestone directory convention and all real logs; create empty folders on demand. |
| `Worker_Log/README.md` | Merge; retire | **AGENTS.md and the two log templates**. Its 1,528 words substantially restate role, attempt, snapshot and acceptance rules already spread through other pages. Preserve rules and history, not a second mandatory rulebook. |

### Documentation entry points and indexes

| Current file | Action | Destination and reason |
|---|---|---|
| `docs/README.md` | Merge navigation; retire | **Root README.md**. Multiple indexes route readers among the same small set of documents. Preserve the milestone/gate/dependency/log-folder table and source-of-truth rules once. |
| `docs/project-0/DOCUMENTATION_QA.md` | Retire to historical snapshot | **Pre-cleanup commit and existing documentation evidence**. Edition provenance, old delivery task, package/patch instructions or past QA. Keep retrievable with the submitted report, not as instructions every future implementation worker must consume. |
| `docs/project-0/PROVENANCE.md` | Retire to historical snapshot | **Pre-cleanup commit and existing documentation evidence**. Edition provenance, old delivery task, package/patch instructions or past QA. Keep retrievable with the submitted report, not as instructions every future implementation worker must consume. |
| `docs/project-0/QUALIFICATION_MATRIX.md` | Merge; retire | **STATUS.md; invariant rules in S07**. Retain CPU/GPU/model/protocol applicability and unsupported scope, but do not maintain another live status surface. |
| `docs/project-0/README.md` | Merge navigation; retire | **Root README.md**. Multiple indexes route readers among the same small set of documents. Preserve the milestone/gate/dependency/log-folder table and source-of-truth rules once. |
| `docs/project-0/REQUIREMENTS.md` | Keep as optional locator | **Same path**. The 32 stable IDs are useful for audits. Keep concise statements and owning spec/gate links; retire exhaustive reverse test lists or generate them only when needed. |
| `docs/project-0/STATUS.md` | Keep; simplify | **Same path**. One live progress summary linked to actual logs, unresolved findings and exact tested profiles. Remove mandatory synchronization with a hand-edited JSON mirror. |
| `docs/project-0/TEST_CATALOG.md` | Retire live copy | **Gate-local acceptance tables**. All 82 planned node IDs also appear in their gate and plan-index.json. Gate-local assertions should be the one planning authority; future implemented tests supply executable evidence. |
| `docs/project-0/plan-index.json` | Retire live copy | **Gate pages + REQUIREMENTS.md + STATUS.md**. 2,385-line hand-maintained mirror. Only the historical documentation checker reads it as code in this snapshot. Preserve in pre-cleanup history; confirm no external consumer before removal. |

### Gate files

| Current file | Action | Destination and reason |
|---|---|---|
| `docs/project-0/gates/G00-environment-and-provenance.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G01-identity-partition-and-contracts.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G02-analytic-force-in-native-atm.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G03-atom-routing-and-integration.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G04-link-boundary-and-derivatives.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G05-local-model-adapter.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G06-periodicity-and-interaction-ledger.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G07-joint-cavity-ligand-atm.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G08-thermodynamics-and-estimators.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G09-solvent-preparation-and-export.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G10-restart-and-replica-exchange.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G11-protein-abfe.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G12-dual-ligand-rbfe.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/G13-performance-and-release.md` | Keep; remove shared boilerplate | **Same path**. Canonical task scope, prerequisites, task IDs, expected assertions, commands and handoff location. Preserve all technical tests; give task-specific reading anchors, not a generic whole-gate reading tour. |
| `docs/project-0/gates/README.md` | Merge navigation; retire | **Root README.md**. Multiple indexes route readers among the same small set of documents. Preserve the milestone/gate/dependency/log-folder table and source-of-truth rules once. |

### Milestone files

| Current file | Action | Destination and reason |
|---|---|---|
| `docs/project-0/milestones/M00-architecture-review.md` | Keep; shorten | **Same path**. A design decision is distinct from a numerical gate. Keep one scoped approval checklist while decisions remain proposed; do not restart an already approved review every session. |
| `docs/project-0/milestones/M01-reproducible-foundation.md` | Merge review; retire page | **G01 closing review + roadmap**. Preserve the distinct combined-system acceptance conditions and milestone ID, but place them at the final constituent gate. Especially redundant for one-gate milestones M04/M06/M07/M08. |
| `docs/project-0/milestones/M02-transfer-kernel.md` | Merge review; retire page | **G03 closing review + roadmap**. Preserve the distinct combined-system acceptance conditions and milestone ID, but place them at the final constituent gate. Especially redundant for one-gate milestones M04/M06/M07/M08. |
| `docs/project-0/milestones/M03-mechanical-hybrid.md` | Merge review; retire page | **G07 closing review + roadmap**. Preserve the distinct combined-system acceptance conditions and milestone ID, but place them at the final constituent gate. Especially redundant for one-gate milestones M04/M06/M07/M08. |
| `docs/project-0/milestones/M04-thermodynamic-accounting.md` | Merge review; retire page | **G08 closing review + roadmap**. Preserve the distinct combined-system acceptance conditions and milestone ID, but place them at the final constituent gate. Especially redundant for one-gate milestones M04/M06/M07/M08. |
| `docs/project-0/milestones/M05-solvated-workflow.md` | Merge review; retire page | **G10 closing review + roadmap**. Preserve the distinct combined-system acceptance conditions and milestone ID, but place them at the final constituent gate. Especially redundant for one-gate milestones M04/M06/M07/M08. |
| `docs/project-0/milestones/M06-abfe-demonstration.md` | Merge review; retire page | **G11 closing review + roadmap**. Preserve the distinct combined-system acceptance conditions and milestone ID, but place them at the final constituent gate. Especially redundant for one-gate milestones M04/M06/M07/M08. |
| `docs/project-0/milestones/M07-rbfe-demonstration.md` | Merge review; retire page | **G12 closing review + roadmap**. Preserve the distinct combined-system acceptance conditions and milestone ID, but place them at the final constituent gate. Especially redundant for one-gate milestones M04/M06/M07/M08. |
| `docs/project-0/milestones/M08-project-1-handover.md` | Merge review; retire page | **G13 closing review + roadmap**. Preserve the distinct combined-system acceptance conditions and milestone ID, but place them at the final constituent gate. Especially redundant for one-gate milestones M04/M06/M07/M08. |
| `docs/project-0/milestones/README.md` | Merge navigation; retire | **Root README.md**. Multiple indexes route readers among the same small set of documents. Preserve the milestone/gate/dependency/log-folder table and source-of-truth rules once. |

### Shared specifications

| Current file | Action | Destination and reason |
|---|---|---|
| `docs/project-0/specs/README.md` | Merge navigation; retire | **Root README.md**. Multiple indexes route readers among the same small set of documents. Preserve the milestone/gate/dependency/log-folder table and source-of-truth rules once. |
| `docs/project-0/specs/S01-scope-and-invariants.md` | Keep; read by section | **Same path**. Authoritative scientific/interface definitions shared across gates. Remove repeated procedural boilerplate, not equations, units, force/constraint conventions, scope or acceptance meaning. |
| `docs/project-0/specs/S02-architecture-and-dependencies.md` | Keep; read by section | **Same path**. Authoritative scientific/interface definitions shared across gates. Remove repeated procedural boilerplate, not equations, units, force/constraint conventions, scope or acceptance meaning. |
| `docs/project-0/specs/S03-data-and-interface-contracts.md` | Keep; read by section | **Same path**. Authoritative scientific/interface definitions shared across gates. Remove repeated procedural boilerplate, not equations, units, force/constraint conventions, scope or acceptance meaning. |
| `docs/project-0/specs/S04-embedding-and-model-contracts.md` | Keep; read by section | **Same path**. Authoritative scientific/interface definitions shared across gates. Remove repeated procedural boilerplate, not equations, units, force/constraint conventions, scope or acceptance meaning. |
| `docs/project-0/specs/S05-protocol-and-thermodynamic-contracts.md` | Keep; read by section | **Same path**. Authoritative scientific/interface definitions shared across gates. Remove repeated procedural boilerplate, not equations, units, force/constraint conventions, scope or acceptance meaning. |
| `docs/project-0/specs/S06-validation-and-tolerances.md` | Keep; read by section | **Same path**. Authoritative scientific/interface definitions shared across gates. Remove repeated procedural boilerplate, not equations, units, force/constraint conventions, scope or acceptance meaning. |
| `docs/project-0/specs/S07-artifacts-and-qualification.md` | Keep; read by section | **Same path**. Authoritative scientific/interface definitions shared across gates. Remove repeated procedural boilerplate, not equations, units, force/constraint conventions, scope or acceptance meaning. |

### Guides and decisions

| Current file | Action | Destination and reason |
|---|---|---|
| `docs/project-0/decisions/ADR-0001-independent-components.md` | Merge rationale; retire | **S02; exact probes remain in S04/S05 and gates**. These short proposed decisions are worth preserving, but their decisions already overlap the specs. Keep alternatives and proposed/approved status; do not create implied approval during cleanup. |
| `docs/project-0/decisions/ADR-0002-early-extension-contracts.md` | Merge rationale; retire | **S02; exact probes remain in S04/S05 and gates**. These short proposed decisions are worth preserving, but their decisions already overlap the specs. Keep alternatives and proposed/approved status; do not create implied approval during cleanup. |
| `docs/project-0/decisions/README.md` | Merge navigation; retire | **Root README.md**. Multiple indexes route readers among the same small set of documents. Preserve the milestone/gate/dependency/log-folder table and source-of-truth rules once. |
| `docs/project-0/guides/adding-a-model-or-embedding.md` | Merge; retire | **S02/S04/S05 extension subsections**. Useful conditional reference, mostly repeating existing ownership and capability rules. Preserve extension-specific cautions; never require it for an identity-only task. |
| `docs/project-0/guides/assigning-work.md` | Merge; retire | **One short root README example + AGENTS.md**. Useful human prompt examples, not a separate agent prerequisite. Preserve worker/audit/repair distinction without repeating the complete workflow. |
| `docs/project-0/guides/documentation-maintenance.md` | Retire to historical snapshot | **Pre-cleanup commit and existing documentation evidence**. Edition provenance, old delivery task, package/patch instructions or past QA. Keep retrievable with the submitted report, not as instructions every future implementation worker must consume. |
| `docs/project-0/guides/repository-integration.md` | Retire to historical snapshot | **Pre-cleanup commit and existing documentation evidence**. Edition provenance, old delivery task, package/patch instructions or past QA. Keep retrievable with the submitted report, not as instructions every future implementation worker must consume. |
| `docs/project-0/guides/spec-and-test-workflow.md` | Merge; retire | **AGENTS.md; numeric probe example into G02 or S04**. Global test-first/repair rules are repeated. Preserve the unique analytic numbers and fault-injection example before deletion. |

### Reference material

| Current file | Action | Destination and reason |
|---|---|---|
| `docs/project-0/reference/coverage-map.md` | Retire to historical snapshot | **Pre-cleanup commit and existing documentation evidence**. Edition provenance, old delivery task, package/patch instructions or past QA. Keep retrievable with the submitted report, not as instructions every future implementation worker must consume. |
| `docs/project-0/reference/environment.md` | Merge; retire | **ATM_MLMM_Environment.md**. Competing environment recipe with a venv/pip route while the root guide/YAML use Conda. Keep one primary requested Conda route and explicit platform qualifications. |
| `docs/project-0/reference/glossary.md` | Keep; optional reading | **Same path**. Small, useful colleague-facing reference. Link unfamiliar terms; never require reading it end to end. |
| `docs/project-0/reference/original-brainstorming-plan.md` | Keep as history | **Same path initially**. Different historical generations, not byte-identical duplicates. Exclude from routine required reading; preserve source identity and superseded status. |
| `docs/project-0/reference/scientific-notes.md` | Merge unique science; retire | **S04, G05 and G13**. Move the free-energy correction equation/overlap warning to S04, model-data limitations to S04/G05, throughput equations and Project-1 handover to G13. Do not delete these unique details. |
| `docs/project-0/reference/sources.md` | Keep; optional lookup | **Same path**. Traceable source material is not workflow bloat. Keep stable source IDs and differentiate inherited claims from newly verified sources. |

### Templates

| Current file | Action | Destination and reason |
|---|---|---|
| `docs/project-0/templates/audit-log.md` | Keep; shorten template | **Same path**. One independent-review format. Keep exact audited scope/snapshot, actual checks, actionable findings with closure criteria and verdict; scale length to the task. |
| `docs/project-0/templates/gate-evidence.md` | Merge applicable fields; retire | **AGENTS.md and worker/audit templates**. A checklist already largely covered by the two log templates and S07. Preserve requirement-to-observed-test mapping without another form. |
| `docs/project-0/templates/milestone-review.md` | Merge applicable fields; retire | **AGENTS.md and worker/audit templates**. Keep combined-snapshot and scope checks in the final gate review and audit template, not a third report format. |
| `docs/project-0/templates/pull-request.md` | Merge applicable fields; retire | **AGENTS.md and worker/audit templates**. No repository workflow consumes this template in the snapshot. An actual PR can link the worker/audit evidence instead of repeating it. |
| `docs/project-0/templates/spec-change.md` | Merge applicable fields; retire | **AGENTS.md and worker/audit templates**. Preserve review, impact, affected evidence and migration obligations as a conditional log/spec amendment section. No extra form for unchanged scientific behavior. |
| `docs/project-0/templates/task.md` | Merge applicable fields; retire | **AGENTS.md and worker/audit templates**. A task path, task ID, scope, relevant prior audit and log destination can be supplied in the assignment; no separate Markdown brief is required. |
| `docs/project-0/templates/worker-log.md` | Keep; shorten template | **Same path**. One implementation handoff format. Keep requested metadata, exact snapshot, references, changes, actual checks, unresolved findings and next action; omit empty not-applicable tables. |

## 8. Metadata that can be removed without changing the science

The ZIP contains 375 AppleDouble/resource-fork files under `__MACOSX/`, six `.DS_Store` files, and 149 files belonging to `.git`. These are separate categories, not 530 useless project source files.

Remove `__MACOSX/` and `.DS_Store` from shared source archives. Four Finder metadata files are actually tracked in the supplied Git index: `.DS_Store`, `Worker_Log/.DS_Store`, `Worker_Log/Milestone_00/.DS_Store`, and `Worker_Log/Milestone_00/evidence/.DS_Store`. Two additional Finder files are untracked under `docs/` and `docs/project-0/`. Remove tracked metadata deliberately and ignore future copies. No `.gitignore` is present in this snapshot.

A minimal proposed ignore addition is:

```gitignore
.DS_Store
__MACOSX/
._*
```

**Do not delete `.git` from the working repository.** It contains version-control state/history, not documentation bloat. Omit it from an ordinary clean source ZIP when that ZIP is not intended to be a full repository backup. The uploaded ZIP's `.git` made the historical snapshot and tracked/untracked distinction inspectable during this audit.

## 9. What must not be lost

Preserve all existing submitted logs and evidence; the milestone-directory and numbered worker/audit convention; fixed ML membership and complete ligand rules; force/energy consistency and link-parent derivatives; explicit periodic/constraint/thermodynamic definitions; both protocol shapes and the inexpensive extension-boundary probes; independent expected answers; and scoped CPU/GPU/model qualification.

The project's original design explicitly called for the smallest scientifically correct problem, avoiding unnecessary generality and testing layers independently. This recommendation applies the same discipline to the documentation: keep the definitions and evidence, and remove the repeated instructions for managing them.
