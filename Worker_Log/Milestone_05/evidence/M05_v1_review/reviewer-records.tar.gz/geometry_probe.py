from pathlib import Path
from itertools import product
import numpy as np,json
from atm_mlmm.workflow import load_configuration
root=Path('/workspace/AToM_MLMM'); report={}; images=np.array(list(product((-6.4,0,6.4),repeat=3)))
radii={'H':.12,'C':.17,'O':.152,'N':.155}
for kind in ('abfe','rbfe'):
 c=load_configuration(root/f'fixtures/solvated_fragment/v2/{kind}/config.json'); t=c.original.topology; ids=list(c.snapshot.real_atom_ids); idx={a:i for i,a in enumerate(ids)}; x=np.array(c.snapshot.positions_nm); mapped=x.copy()
 ligands=[m for m in t.molecules if m.role=='ligand']
 for sign,m in zip((1,-1),ligands): mapped[[idx[a] for a in m.atom_ids]]+=np.array((2.4*sign,0,0))
 caps=[]
 for a,b in c.partition.permitted_cuts:
  d=x[idx[b]]-x[idx[a]];caps.append(x[idx[a]]+.109*d/np.linalg.norm(d))
 mins=[]
 for frame in (x,mapped):
  water_min=99.;cap_water=99.;cap_ligand=99.
  for i,m in enumerate(t.molecules):
   a=[idx[v] for v in m.atom_ids]
   for other in t.molecules[i+1:]:
    if 'solvent' not in (m.role,other.role): continue
    b=[idx[v] for v in other.atom_ids]
    dist=np.linalg.norm(frame[a,None,None,:]-frame[None,b,None,:]+images[None,None,:,:],axis=-1).min(axis=-1)
    scale=np.array([radii[t.atoms[j].element] for j in a])[:,None]+np.array([radii[t.atoms[j].element] for j in b])[None,:]
    water_min=min(water_min,float((dist/scale).min()))
   if m.role in ('solvent','ligand'):
    dist=np.linalg.norm(frame[a,None,None,:]-np.array(caps)[None,:,None,:]+images[None,None,:,:],axis=-1).min(axis=-1)
    ratio=float((dist/(np.array([radii[t.atoms[j].element] for j in a])[:,None]+.12)).min())
    if m.role=='solvent':cap_water=min(cap_water,ratio)
    else:cap_ligand=min(cap_ligand,ratio)
  mins.append(dict(water_other_min_ratio=water_min,water_cap_min_ratio=cap_water,ligand_cap_min_ratio=cap_ligand))
  assert water_min>=.8 and cap_water>=.8 and cap_ligand>=.8
 report[kind]=mins
Path('/workspace/m05-evidence/reviewer-v1/geometry-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
