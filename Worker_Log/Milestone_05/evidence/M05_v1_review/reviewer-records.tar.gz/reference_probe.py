import json,hashlib
from pathlib import Path
import numpy as np
from atm_mlmm.tpu_experiment import read_reference
out=Path('/workspace/m05-evidence/reviewer-v1');path=out/'extracted/cpu-tpu-reference/cpu-tpu-reference/reference.json'
ref=read_reference(path,'8a625d5bdcbac5cc1ddeb244ff12d095b14f811a287ca18732f86c943dba8d73')
report={'rows':len(ref['rows']),'source_sha':ref['source_sha'],'source_dirty':ref['source_dirty'],'configurations':[]}
assert len(ref['rows'])==108
for case in ref['cases']:
 for mapping in (0,1):
  rows=[r for r in ref['rows'] if r['case']==case['kind'] and r['map']==mapping];base=next(r for r in rows if r['variant']=='base');ids=case['real_atom_ids'];x=np.array(base['real_positions_nm']);m=base['model'];force=np.array(m['forces_kj_mol_nm']);full=np.zeros_like(x)
  for atom,f in zip(case['model_input_ids'],force):
   if atom in ids:full[ids.index(atom)]+=f
   else:
    link=next(l for l in case['links'] if l['cap_id']==atom);a,b=(ids.index(link[k]) for k in ('ml_parent_id','mm_parent_id'));v=x[b]-x[a];length=np.linalg.norm(v);u=v/length
    b_force=link['distance_nm']/length*(f-u*np.dot(u,f));full[b]+=b_force;full[a]+=f-b_force
  projection_error=float(abs(full-np.array(base['all_real_ml_forces'])).max());assert projection_error<1e-10
  checks=[]
  for atom in {r['fd_atom'] for r in rows if r['variant']=='fd'}:
   errors=[]
   for step in ref['fd_steps_nm']:
    pair={r['sign']:r['energy_kj_mol'] for r in rows if r['variant']=='fd' and r['fd_atom']==atom and r['step_nm']==step};fd=(pair[-1]-pair[1])/(2*step);errors.append(abs(fd-full[atom,1]))
   assert errors[-1]<=1e-3+1e-4*abs(full[atom,1]);assert errors[-1]<=errors[0]+1e-4
   checks.append({'atom':ids[atom],'errors':errors})
  graph=next(r for r in rows if r['variant']=='graph-shape')
  report['configurations'].append({'case':case['kind'],'map':mapping,'projection_max_error':projection_error,'fd_sweeps':checks,'base_edges':len(m['directed_edges']),'changed_edges':len(graph['model']['directed_edges'])})
assert any(c['base_edges']!=c['changed_edges'] for c in report['configurations'])
(out/'reference-check.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS 108 CPU reference configurations; 4 independent cap projections; 16 three-step real-coordinate FD sweeps; graph changes verified')
