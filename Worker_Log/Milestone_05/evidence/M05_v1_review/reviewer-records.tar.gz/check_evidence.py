import hashlib,json,tarfile,subprocess
from pathlib import Path
import xml.etree.ElementTree as ET
from atm_mlmm.evidence import verify_evidence
from atm_mlmm.exchange_journal import read_exchange_rounds
root=Path('/workspace/AToM_MLMM'); evidence=root/'Worker_Log/Milestone_05/evidence/M05_v1'; out=Path('/workspace/m05-evidence/reviewer-v1'); report={}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for name,base in [('scientific-files.json',root),('files.json',evidence)]:
 data=json.loads((evidence/name).read_text()); mismatch=[k for k,v in data.items() if sha(base/k)!=v]
 report[name]={'verified':len(data),'mismatch':mismatch}; assert not mismatch
report['head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert report['head']=='bc6fd520308fba7e7448929138eb91e80ca6f063'
report['scientific_diff']=subprocess.check_output(['git','diff','424a859732b77b2f91cd03b12bb3f0b8adf3f541',report['head'],'--','src','tests','tools','fixtures','environment','notebooks/*.ipynb'],cwd=root,text=True)
assert not report['scientific_diff']
report['archives']={}
for name,data in json.loads((evidence/'archives.json').read_text()).items():
 assert sha(evidence/name)==data['sha256'] and (evidence/name).stat().st_size==data['bytes']
 target=out/'extracted'/name.removesuffix('.tar.gz'); target.mkdir(parents=True)
 with tarfile.open(evidence/name) as tar:
  for m in tar.getmembers():
   assert not m.issym() and not m.islnk() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  tar.extractall(target,filter='data')
 seals=list(target.rglob('.evidence.json'))
 r={'archive_hash_verified':True}
 if data.get('sealed_export'):
  assert len(seals)==1
  attempt=seals[0].parent; seal=verify_evidence(attempt); assert seal==data['sealed_export']
  r['sealed_files']=len(seal['files']);r['root']=str(attempt)
  if (attempt/'rounds').exists():
   rows=read_exchange_rounds(attempt); r['rounds']=len(rows);r['samples']=sum(len(row['samples']) for row in rows)
   error=0.
   from atm_mlmm.schema import from_json
   records=from_json((attempt/'records.json').read_text()); states={s.state_id:s for s in records.schedule.states}
   import math
   for row in rows:
    matrix=[]
    for sid in row['exchange']['state_ids_before']:
     p=states[sid].parameters; energies=[]
     for sample in row['samples']:
      raw=sample['raw'];u0=raw['u0_raw_kJ_mol'];u1=raw['u1_raw_kJ_mol'];u=p['Direction']*(u1-u0-p['UOffset'])
      if p['Acore'] and u>p['Ubcore']:
       y=(u-p['Ubcore'])/(p['Umax']-p['Ubcore']);z=1+2*y/p['Acore']+2*(y/p['Acore'])**2
       u=(p['Umax']-p['Ubcore'])*(z**p['Acore']-1)/(z**p['Acore']+1)+p['Ubcore']
      v=(u0 if p['Direction']>0 else u1)+p['Lambda2']*u+p['W0']+raw['outside_energy_kJ_mol']
      if p['Lambda2']!=p['Lambda1']: v+=(p['Lambda2']-p['Lambda1'])/p['Alpha']*math.log1p(math.exp(-p['Alpha']*(u-p['Uh'])))
      energies.append(v/(.00831446261815324*300))
     matrix.append(energies)
    error=max(error,max(abs(matrix[i][j]-row['exchange']['reduced_energies'][i][j]) for i in range(2) for j in range(2)))
   r['independent_exchange_matrix_max_error']=error;assert error<1e-8
 report['archives'][name]=r
suite=ET.parse(evidence/'full-suite-final.xml').getroot()[0]; report['submitted_junit']=suite.attrib
(out/'evidence-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
