from pathlib import Path
import shutil,random
import numpy as np,pytest
from tests.workflow.test_persistent_exchange import prepared

@pytest.mark.parametrize('fault', ['decision-prewrite','second-checkpoint','hard-interrupt'])
def test_additional_boundaries_replay_exactly(prepared,tmp_path,monkeypatch,fault):
 import atm_mlmm.exchange as e
 output=tmp_path/'run';e.run_exchange(prepared,output,rounds=3,steps_per_round=2,seed=179,trusted=True,stop_after_rounds=1)
 reference=tmp_path/'reference';shutil.copytree(output,reference);e.resume_exchange(reference,trusted=True)
 py=random.getstate();npy=np.random.get_state()
 with monkeypatch.context() as m:
  if fault=='second-checkpoint':
   original=e._capture
   def bad(worker,path,w):
    if w==1:raise OSError('independent second-worker checkpoint interruption')
    return original(worker,path,w)
   m.setattr(e,'_capture',bad);error=OSError
  else:
   original=e._record_phase
   def bad(path,phase,report):
    if phase=='decision':
     if fault=='hard-interrupt':raise KeyboardInterrupt('independent hard interrupt before decision save')
     raise OSError('independent decision write failed before bytes')
    return original(path,phase,report)
   m.setattr(e,'_record_phase',bad);error=KeyboardInterrupt if fault=='hard-interrupt' else OSError
  with pytest.raises(error):e.resume_exchange(output,trusted=True)
 assert random.getstate()==py
 after=np.random.get_state();assert after[0]==npy[0] and after[2:]==npy[2:];np.testing.assert_array_equal(after[1],npy[1])
 pending=next((output/'rounds').glob('.pending-*'));saved={p.relative_to(pending):p.read_bytes() for p in pending.rglob('*') if p.is_file()}
 assert not (output/'rounds/000001').exists()
 with pytest.raises(ValueError,match='incomplete'):e.resume_exchange(output,trusted=True)
 e.resume_exchange(output,trusted=True,recover_pending=True)
 assert e.read_exchange_rounds(output)==e.read_exchange_rounds(reference)
 archived=next((output/'failures').glob('rollback-*'))
 for name,data in saved.items():assert (archived/name).read_bytes()==data
 for index in (0,1,2):
  assert (output/f'rounds/{index:06d}/rng.json').read_bytes()==(reference/f'rounds/{index:06d}/rng.json').read_bytes()
