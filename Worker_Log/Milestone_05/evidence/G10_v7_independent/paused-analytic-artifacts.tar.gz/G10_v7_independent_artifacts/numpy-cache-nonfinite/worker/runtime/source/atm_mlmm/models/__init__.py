"""Lazy physical model adapters."""
