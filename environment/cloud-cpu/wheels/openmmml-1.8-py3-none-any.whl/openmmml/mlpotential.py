"""
mlpotential.py: Provides a common API for creating OpenMM Systems with ML potentials.

This is part of the OpenMM molecular simulation toolkit originating from
Simbios, the NIH National Center for Physics-Based Simulation of
Biological Structures at Stanford, funded under the NIH Roadmap for
Medical Research, grant U54 GM072970. See https://simtk.org.

Portions copyright (c) 2021-2026 Stanford University and the Authors.
Authors: Peter Eastman
Contributors:

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS, CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

import openmm
import openmm.app
from collections.abc import Iterable
import os
import shutil
import tempfile
import typing
import urllib.request
import sys
if sys.version_info < (3, 10):
    from importlib_metadata import entry_points
else:
    from importlib.metadata import entry_points


class MLPotentialImplFactory(object):
    """Abstract interface for classes that create MLPotentialImpl objects.

    If you are defining a new potential function, you need to create subclasses
    of MLPotentialImpl and MLPotentialImplFactory, and register an instance of
    the factory by calling MLPotential.registerImplFactory().  Alternatively,
    if a Python package creates an entry point in the group "openmmml.potentials",
    the potential will be registered automatically.  The entry point name is the
    name of the potential function, and the value should be the name of the
    MLPotentialImplFactory subclass.
    """

    def createImpl(self, name: str, **args) -> "MLPotentialImpl":
        """Create a MLPotentialImpl that will be used to implement a MLPotential.

        When a MLPotential is created, it invokes this method to create an object
        implementing the requested potential.  Subclasses must implement this method
        to return an instance of the correct MLPotentialImpl subclass.

        Parameters
        ----------
        name: str
            the name of the potential that was specified to the MLPotential constructor
        args:
            any additional keyword arguments that were provided to the MLPotential
            constructor are passed to this method.  This allows subclasses to customize
            their behavior based on extra arguments.

        Returns
        -------
        a MLPotentialImpl that implements the potential
        """
        raise NotImplementedError('Subclasses must implement createImpl()')


class MLPotentialImpl(object):
    """Abstract interface for classes that implement potential functions.

    If you are defining a new potential function, you need to create subclasses
    of MLPotentialImpl and MLPotentialImplFactory.  When a user creates a
    MLPotential and specifies a name for the potential to use, it looks up the
    factory that has been registered for that name and uses it to create a
    MLPotentialImpl of the appropriate subclass.
    """

    def addForces(self,
                  topology: openmm.app.Topology,
                  system: openmm.System,
                  atoms: Iterable[int] | None,
                  forceGroup: int,
                  **args):
        """Add Force objects to a System to implement the potential function.

        This is invoked by MLPotential.createSystem().  Subclasses must implement
        it to create the requested potential function.

        Parameters
        ----------
        topology: Topology
            the Topology from which the System is being created
        system: System
            the System that is being created
        atoms: Optional[Iterable[int]]
            the indices of atoms the potential should be applied to, or None if
            it should be applied to the entire System
        forceGroup: int
            the force group that any newly added Forces should be in
        args:
            any additional keyword arguments that were provided to createSystem()
            are passed to this method.  This allows subclasses to customize their
            behavior based on extra arguments.
        """
        raise NotImplementedError('Subclasses must implement addForces()')

    def createMixedSystem(self,
                          topology: openmm.app.Topology,
                          system: openmm.System,
                          atoms: list[int],
                          forceGroup: int,
                          interpolate: bool,
                          embedding: str,
                          returnInfo: bool = False,
                          **args) -> openmm.System | dict[str, typing.Any]:
        """Creates a mixed system using a potential-specific embedding method.

        This is invoked by MLPotential.createMixedSystem().  It will only be
        called with one of the names returned by getSupportedEmbeddings().  If
        subclasses support any potential-specific embedding methods, they must
        also provide implementations of those methods by overriding this method.
        If not, it does not need to be implemented.

        Each embedding method is responsible for implementing interpolation; if
        interpolate is True, a global parameter "lambda_interpolate" should be
        present in the returned system, with the behavior as described by
        MLPotential.createMixedSystem().

        Parameters
        ----------
        topology: Topology
            the Topology for which to create a System
        system: System
            a System that models the Topology with a conventional force field
        atoms: Iterable[int]
            the indices of all atoms whose interactions should be computed with
            this potential
        forceGroup: int
            the force group the ML potential's Forces should be placed in
        interpolate: bool
            if True, create a System that can smoothly interpolate between the
            conventional and ML potentials
        embedding: str
            the name of the embedding method (will always be one in the list
            returned by the getSupportedEmbeddings() method)
        returnInfo: bool
            whether to return a dictionary of key-value pairs containing a new
            System with additional information, instead of the System alone
        args:
            any additional arguments for the potential or embedding method

        Returns
        -------
        A newly created System object that uses this potential function and the
        requested embedding method to model the Topology, or a dictionary of
        key-value pairs if the implementation supports returnInfo and it is
        True.  The dictionary must contain the System as 'system', a Topology
        (that may be different from the one provided) as 'topology', and a list
        mapping atom indices in the original Topology to those in the returned
        Topology as 'oldToNew'.  If the implementation does not support
        returnInfo, the System returned must be compatible with the provided
        Topology.  In no case may the implementation modify the given Topology
        in place; it must copy it first or create a new Topology.
        """

        raise NotImplementedError('Subclasses must implement createMixedSystem()')

    def getSupportedEmbeddings(self) -> list[str]:
        """Retrieves a list of names of supported embedding methods (for the
        creation of mixed ML/MM systems) specific to this potential.  If one of
        these names is provided instead of providing the name of a generic
        embedding plugin, embedding will be performed by the potential itself.

        This is invoked by MLPotential.createMixedSystem().  If a subclass
        wishes to define one or more potential-specific embedding methods, it
        should implement this method; otherwise, it does not need to.
        """

        return []

    def getMLLongRange(self) -> bool | None:
        """Returns whether ML interactions are local (False), or long-ranged
        (True) when periodic boundary conditions are present.  This controls
        which interactions are included by some ML/MM embedding methods.
        Consult the documentation for each embedding method for more details.
        None can be returned if the nature of the interactions is not known by
        the MLPotentialImpl.

        The default implementation of this method, used if a subclass does not
        override it, always returns None.
        """

        return None

    def _getTorchDevice(self, args):
        """This is a utility routine for use by subclasses that are implemented with PyTorch.  It selects what device
        to use, which can either by specified by the user with the 'device' argument, or chosen automatically based on
        the available hardware."""
        import torch
        if 'device' in args:
            device = args['device']
            if isinstance(device, str):
                device = torch.device(device)
            return device
        if torch.cuda.is_available():
            return torch.device('cuda')
        return torch.device('cpu')

    def _getCacheDir(self):
        """This is a utility routine returning a cache directory for use by subclasses that need to download their own
        models.  Before returning, it will create the directory and any parent directories if they do not already exist."""
        path = os.path.expanduser("~/.cache/openmm-ml")
        os.makedirs(path, exist_ok=True)
        return path

    def _downloadOrFindFile(self, name: str, url: str):
        """Downloads a file at the requested URL and saves it in a cache directory under the specified name.  If a file
        with the specified name already exists in the cache, the path to it will be returned without downloading it again."""
        cacheDir = self._getCacheDir()
        targetPath = os.path.join(cacheDir, name)
        if not os.path.isfile(targetPath):
            with urllib.request.urlopen(url) as remoteFile:
                # Download into a temporary directory first so that we do not
                # end up with a partially downloaded file at targetPath and we
                # do not create temporary files directly in the cache directory.
                with tempfile.TemporaryDirectory(dir=cacheDir) as tempDir:
                    tempPath = os.path.join(tempDir, name)
                    with open(tempPath, "wb") as localFile:
                        shutil.copyfileobj(remoteFile, localFile)
                    os.replace(tempPath, targetPath)
        return targetPath


class MLPotential(object):
    """A potential function that can be used in simulations.

    To use this class, create a MLPotential, specifying the name of the potential
    function to use.  You can then call createSystem() to create a System object
    for a simulation.  For example,

    >>> potential = MLPotential('ani2x')
    >>> system = potential.createSystem(topology)

    Alternatively, you can use createMixedSystem() to create a System where part is
    modeled with this potential and the rest is modeled with a conventional force
    field.  As an example, suppose the Topology contains three chains.  Chain 0 is
    a protein, chain 1 is a ligand, and chain 2 is solvent.  The following code
    creates a System in which the internal energy of the ligand is computed with
    ANI2x, while everything else (including interactions between the ligand and the
    rest of the System) is computed with Amber14.

    >>> forcefield = ForceField('amber14-all.xml', 'amber14/tip3pfb.xml')
    >>> mm_system = forcefield.createSystem(topology)
    >>> chains = list(topology.chains())
    >>> ml_atoms = [atom.index for atom in chains[1].atoms()]
    >>> potential = MLPotential('ani2x')
    >>> ml_system = potential.createMixedSystem(topology, mm_system, ml_atoms)
    """

    _implFactories: dict[str, MLPotentialImplFactory] = {}
    _embeddingFactories: dict[str, "EmbeddingFactory"] = {}

    def __init__(self, name: str, **args):
        """Create a MLPotential.

        Parameters
        ----------
        name: str
            the name of the potential function to use.  Built in support is currently
            provided for the following: 'ani1ccx', 'ani2x'.  Others may be added by
            calling MLPotential.registerImplFactory().
        args:
            particular potential functions may define additional arguments that can
            be used to customize them.  See the documentation on the specific
            potential functions for more information.
        """
        self._impl = MLPotential._implFactories[name].createImpl(name, **args)

    def createSystem(self, topology: openmm.app.Topology, removeCMMotion: bool = True, **args) -> openmm.System:
        """Create a System for running a simulation with this potential function.

        Parameters
        ----------
        topology: Topology
            the Topology for which to create a System
        removeCMMotion: bool
            if true, a CMMotionRemover will be added to the System.
        args:
            particular potential functions may define additional arguments that can
            be used to customize them.  See the documentation on the specific
            potential functions for more information.

        Returns
        -------
        a newly created System object that uses this potential function to model the Topology
        """
        system = openmm.System()
        if topology.getPeriodicBoxVectors() is not None:
            system.setDefaultPeriodicBoxVectors(*topology.getPeriodicBoxVectors())
        for atom in topology.atoms():
            if atom.element is None:
                system.addParticle(0)
            else:
                system.addParticle(atom.element.mass)
        self._impl.addForces(topology, system, None, 0, **args)
        if removeCMMotion:
            system.addForce(openmm.CMMotionRemover())
        return system

    def createMixedSystem(self,
                          topology: openmm.app.Topology,
                          system: openmm.System,
                          atoms: Iterable[int],
                          removeConstraints: bool = True,
                          forceGroup: int = 0,
                          interpolate: bool = False,
                          embedding: str = 'mechanical',
                          returnInfo: bool = False,
                          **args) -> openmm.System | dict[str, typing.Any]:
        """Create a System that is partly modeled with this potential and partly
        with a conventional force field.

        To use this method, first create a System that is entirely modeled with
        the conventional force field.  Pass it to this method, along with the
        indices of the atoms to model with this potential (the "ML subset").

        If interpolate is False, the resulting system will compute the
        interactions between atoms outside of the ML subset with the
        conventional force field, the interactions between atoms within the ML
        subset with the ML potential, and the interactions between atoms within
        and outside of the ML subset according to a selectable embedding method.

        If interpolate is True, a global parameter "lambda_interpolate" will be
        made available permitting linear interpolation between the conventional
        force field and the mixed ML/MM system.  When lambda_interpolate=0, the
        energy is computed entirely with the conventional force field.  When
        lambda_interpolate=1, the energy is computed with the ML potential and
        the selected embedding method.  You can set its value by calling
        setParameter() on the Context.

        Parameters
        ----------
        topology: Topology
            the Topology for which to create a System
        system: System
            a System that models the Topology with a conventional force field
        atoms: Iterable[int]
            the indices of all atoms whose interactions should be computed with
            this potential
        removeConstraints: bool
            if True, remove constraints between pairs of atoms whose interaction
            will be computed with this potential
        forceGroup: int
            the force group the ML potential's Forces should be placed in
        interpolate: bool
            if True, create a System that can smoothly interpolate between the
            conventional and ML potentials
        embedding: str
            the name of the embedding method.  The builtin 'mechanical'
            embedding method is used by default.  Other generic embedding
            methods may be available, as well as embedding methods specific to
            the ML potential selected.  MLPotential.getSupportedEmbeddings()
            will report all embedding methods accepted by the potential.
        returnInfo: bool
            whether to return a dictionary of key-value pairs containing a new
            System with additional information, instead of the System alone
        args:
            particular potential functions or embedding methods may define
            additional arguments that can be used to customize them.  See the
            documentation on the specific potential functions and embedding
            methods for more information.

        Returns
        -------
        A newly created System object that uses this potential function and the
        requested embedding method to model the Topology, or a dictionary of
        key-value pairs if returnInfo is True.  The dictionary will contain the
        System as 'system', a (possibly modified) Topology as 'topology', and a
        list mapping atom indices in the original Topology to those in the
        returned Topology as 'oldToNew'.
        """

        atomList = list(atoms)

        # See if we are given an embedding name that the potential can handle.
        customEmbeddings = self._impl.getSupportedEmbeddings()
        if embedding in customEmbeddings:
            systemOrInfo = self._impl.createMixedSystem(topology, system, atomList, forceGroup, interpolate, embedding, returnInfo=returnInfo, **args)
        else:
            # Fall back on an embedding plugin.
            embeddingInstance = MLPotential._embeddingFactories[embedding].createEmbedding(embedding)
            systemOrInfo = embeddingInstance.createMixedSystem(self._impl, topology, system, atomList, forceGroup, interpolate, returnInfo=returnInfo, **args)

        if returnInfo:
            if isinstance(systemOrInfo, openmm.System):
                # The potential or embedding didn't support returnInfo.
                info = dict(system=systemOrInfo, topology=topology, oldToNew=list(range(topology.getNumAtoms())))
            else:
                info = systemOrInfo
            system = info["system"]
        else:
            system = systemOrInfo

        if removeConstraints:
            # Remove all constraints with both atoms in the ML subset.
            atomSet = set(atoms)
            constraintsToRemove = []
            for constraint in range(system.getNumConstraints()):
                p1, p2, _ = system.getConstraintParameters(constraint)
                if p1 in atomSet and p2 in atomSet:
                    constraintsToRemove.append(constraint)
            for constraint in reversed(constraintsToRemove):
                system.removeConstraint(constraint)

        return info if returnInfo else system

    def getSupportedEmbeddings(self) -> list[str]:
        """Retrieves a list of the names of all of the supported embedding
        methods for this potential.  This includes all available generic
        embedding methods and all of those specific to the potential.
        """

        return sorted(set(MLPotential._embeddingFactories.keys()) | set(self._impl.getSupportedEmbeddings()))

    @staticmethod
    def registerImplFactory(name: str, factory: MLPotentialImplFactory):
        """Register a new potential function that can be used with MLPotential.

        Parameters
        ----------
        name: str
            the name of the potential function that will be passed to the MLPotential constructor
        factory: MLPotentialImplFactory
            a factory object that will be used to create MLPotentialImpl objects
        """
        MLPotential._implFactories[name] = factory

    @staticmethod
    def registerEmbeddingFactory(name: str, factory: "EmbeddingFactory"):
        """Register a new embedding method that can be used with MLPotential.

        Parameters
        ----------
        name: str
            the name of the embedding method to register for use
        factory: MLPotentialImplFactory
            a factory object that will be used to create Embedding objects
        """
        MLPotential._embeddingFactories[name] = factory


class EmbeddingFactory:
    """Abstract interface for classes that create Embedding objects.

    If you are defining a new embedding method, you need to create subclasses of
    Embedding and EmbeddingFactory, and register an instance of the factory by
    calling MLPotential.registerEmbeddingFactory().  Alternatively, if a Python
    package creates an entry point in the group "openmmml.embeddings", the
    embedding will be registered automatically.  The entry point name is the
    name of the embedding method, and the value should be the name of the
    EmbeddingFactory subclass.
    """

    def createEmbedding(self, name: str) -> "Embedding":
        """Create an Embedding that will be used to implement an embedding
        method.

        When a mixed ML/MM system is created with an MLPotential, it invokes
        this method to create an object implementing the requested embedding.
        Subclasses must implement this method to return an instance of the
        correct Embedding subclass.

        Parameters
        ----------
        name: str
            the name of the embedding given to MLPotential.createMixedSystem()

        Returns
        -------
        an Embedding instance that implements the embedding
        """

        raise NotImplementedError('Subclasses must implement createEmbedding()')


class Embedding:
    """Abstract interface for classes that implement embedding methods.

    If you are defining a new embedding method, you need to create subclasses of
    of Embedding and EmbeddingFactory.  When a user specifies a name for an
    embedding method that is not a custom embedding method supported by that
    potential, MLPotential looks up the factory that has been registered for
    that name and uses it to create an Embedding of the appropriate subclass.
    """

    def createMixedSystem(self,
                          potential: MLPotentialImpl,
                          topology: openmm.app.Topology,
                          system: openmm.System,
                          atoms: list[int],
                          forceGroup: int,
                          interpolate: bool,
                          returnInfo: bool = False,
                          **args) -> openmm.System | dict[str, typing.Any]:
        """Creates a mixed system using the embedding method.

        This is invoked by MLPotential.createMixedSystem().  It must be
        implemented in subclasses.  The implementation should call
        potential.addForces() as needed to generate the appropriate ML forces.

        Each embedding method is responsible for implementing interpolation; if
        interpolate is True, a global parameter "lambda_interpolate" should be
        present in the returned system, with the behavior as described by
        MLPotential.createMixedSystem().
        """

        raise NotImplementedError('Subclasses must implement createMixedSystem()')

# Register any potential functions or embeddings defined by entry points.

for potential in entry_points(group='openmmml.potentials'):
    MLPotential.registerImplFactory(potential.name, potential.load()())
for embedding in entry_points(group='openmmml.embeddings'):
    MLPotential.registerEmbeddingFactory(embedding.name, embedding.load()())
