"""
torchmdnetpotential.py: Implements the TorchMD-Net potential function.

This is part of the OpenMM molecular simulation toolkit originating from
Simbios, the NIH National Center for Physics-Based Simulation of
Biological Structures at Stanford, funded under the NIH Roadmap for
Medical Research, grant U54 GM072970. See https://simtk.org.

Portions copyright (c) 2021-2026 Stanford University and the Authors.
Authors: Peter Eastman
Contributors: Stephen Farr

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS, CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
import openmm
from openmm import unit
from openmmml.mlpotential import MLPotentialImpl, MLPotentialImplFactory
from typing import Iterable, Optional
import numpy as np

class TorchMDNetPotentialImplFactory(MLPotentialImplFactory):
    """This is the factory that creates TorchMDNetPotentialImpl objects."""

    def createImpl(
        self, 
        name: str, 
        modelPath: Optional[str] = None,
        lengthScale: float = 0.1, # angstrom -> nm
        energyScale: float = 96.4916,  # eV -> kJ/mol
    ) -> MLPotentialImpl:
        return TorchMDNetPotentialImpl(name, modelPath, lengthScale, energyScale)

class TorchMDNetPotentialImpl(MLPotentialImpl):
    """This is the MLPotentialImpl implementing the TorchMDNet potential.

    The TorchMDNet potential is constructed using `torchmdnet` to build a PyTorch model,
    and then integrated into the OpenMM System using a TorchForce.  To use it, specify the model by name
    and provide the path to a model.

    >>> potential = MLPotential('torchmdnet', modelPath=<model_file_path>)

    The default energy and length scales assume a model is trained with positions in angstroms and energies in eV.
    If this is not the case you can specify the length and energy scales by passing the factors that convert the model
    distance to nm and the energy to kJ/mol, for example:

    >>> potential = MLPotential('torchmdnet', modelPath=<model_file_path>, 
                                lengthScale=0.1 # angstrom to nm, 
                                energyScale=4.184 # kcal/mol to kJ/mol)

    During system creation you can enable CUDA graphs for a speed-up for small molecules:

    >>>  system = potential.createSystem(pdb.topology, cudaGraphs=True)

    The default is to enable this for TensorNet models.

    You can also specify the molecule's total charge:

    >>>  system = potential.createSystem(pdb.topology, charge=0)

    Pretained AceFF models can be used directly:

    >>> potential = MLPotential('aceff-2.0')

    >>> potential = MLPotential('aceff-1.1')

    >>> potential = MLPotential('aceff-1.0')

    Coulomb cutoff behavior
    ------------------------
    The Coulomb cutoff in TorchMD-Net uses a reaction-field approximation. Applying it to a
    non-periodic system introduces errors, so by default the cutoff is only used when the
    system uses periodic boundary conditions.

    You can override this with the ``useCoulombCutoff`` argument if you know which behavior
    you want, for example:

    >>>  system = potential.createSystem(pdb.topology, useCoulombCutoff=False)

    """

    # (Repository ID, filename, long-range)
    KNOWN_MODELS = {
        'aceff-1.0': ('Acellera/AceFF-1.0', 'aceff_v1.0.ckpt', False),
        'aceff-1.1': ('Acellera/AceFF-1.1', 'aceff_v1.1.ckpt', False),
        'aceff-2.0': ('Acellera/AceFF-2.0', 'aceff_v2.0.ckpt', False),
    }

    def __init__(self, 
                 name: str,
                 modelPath: str,
                 lengthScale: float,
                 energyScale: float
    ) -> None:
        """
        Initialize the TorchMDNetPotentialImpl.

        Parameters
        ----------
        name : str
            The name of the model.
            'torchmdnet' for a local model file, or pretrained models are available: 'aceff-1.0' or 'aceff-1.1'. 
        modelPath : str, optional
            The path to the locally trained torchmdnet model if ``name`` is 'torchmdnet'.
        lengthScale : float
            The length conversion factor from the model units to nanometers. 
            If not specified the default is 0.1 which corresponds to a model in angstrom
        energyScale : float
            The energy conversion factor from the model units to kJ/mol.
            If not specified the default is 96.4916 which corresponds to a model in eV.
   
        """
        self.name = name
        self.modelPath = modelPath
        self.lengthScale = lengthScale
        self.energyScale = energyScale

    def addForces(self,
                  topology: openmm.app.Topology,
                  system: openmm.System,
                  atoms: Optional[Iterable[int]],
                  forceGroup: int,
                  **args):
        # Load the TorchMDNet model.
        try:
            import torchmdnet
            from torchmdnet.models.model import load_model
        except ImportError as e:
            raise ImportError(f"Failed to import torchmdnet please install from https://torchmd-net.readthedocs.io/en/latest/installation.html")
        import torch

        includedAtoms = list(topology.atoms())
        if atoms is not None:
            includedAtoms = [includedAtoms[i] for i in atoms]
        device = self._getTorchDevice(args)
        numbers = torch.tensor([atom.element.atomic_number for atom in includedAtoms], device=device, requires_grad=False)
        charge = torch.tensor([args.get('charge', 0)], dtype=torch.float32, device=device, requires_grad=False)
        cutoff = 10*args.get('coulomb_cutoff', 1.2)
        if unit.is_quantity(cutoff):
            cutoff = cutoff.value_in_unit(unit.angstrom)

        if self.name == 'torchmdnet':
            # a local path to a torchmdnet checkpoint must be provided 
            model_file_path = self.modelPath
        else:
            try:
                from huggingface_hub import hf_hub_download
            except ImportError as e:
                raise ImportError(f"Failed to import huggingface_hub please install from https://huggingface.co/docs/huggingface_hub/en/installation")

            if self.name in TorchMDNetPotentialImpl.KNOWN_MODELS:
                repo_id, filename, _ = TorchMDNetPotentialImpl.KNOWN_MODELS[self.name]
            else:
                raise ValueError(f'Model name {self.name} does not exist.')

            model_file_path = hf_hub_download(
                repo_id=repo_id,
                filename=filename,
            )

        periodic = (topology.getPeriodicBoxVectors() is not None) or system.usesPeriodicBoundaryConditions()
        use_coulomb_cutoff = args.get('useCoulombCutoff', periodic)
        model = load_model(
            model_file_path,
            derivative=False,
            remove_ref_energy = args.get('remove_ref_energy', True),
            max_num_neighbors = min(args.get('max_num_neighbors', 64), numbers.shape[0]),
            coulomb_cutoff = cutoff if use_coulomb_cutoff else None,
            static_shapes = True,
            check_errors = False
        ).to(device)
        for parameter in model.parameters():
            parameter.requires_grad = False
        batch = args.get('batch', None)
        if batch is None:
            batch = torch.zeros_like(numbers, requires_grad=False)
        else:
            batch = torch.tensor(batch, dtype=torch.long, device=device, requires_grad=False)

        # Create the PythonForce and add it to the System.

        compute = _ComputeTorchMDNet(model=model,
                                     numbers=numbers,
                                     charge=charge,
                                     batch=batch,
                                     lengthScale=self.lengthScale,
                                     energyScale=self.energyScale,
                                     periodic=periodic)
        force = openmm.PythonForce(compute)
        force.setForceGroup(forceGroup)
        force.setUsesPeriodicBoundaryConditions(periodic)
        if atoms is not None:
            force.setParticles(atoms)
        system.addForce(force)

    def getMLLongRange(self) -> bool | None:
        if self.name in TorchMDNetPotentialImpl.KNOWN_MODELS:
            _, _, longRange = TorchMDNetPotentialImpl.KNOWN_MODELS[self.name]
            return longRange
        return None

class _ComputeTorchMDNet(object):
    def __init__(self, model, numbers, charge, batch, lengthScale, energyScale, periodic):
        self.model = model
        self.compiled_model = None
        self.numbers = numbers
        self.charge = charge
        self.batch = batch
        self.lengthScale = lengthScale
        self.energyScale = energyScale
        self.periodic = periodic
        self.has_recompiled = False

    def __call__(self, state):
        import torch
        positions = state.getPositions(asNumpy=True).value_in_unit(unit.nanometer)
        positions = torch.tensor(positions, dtype=torch.float32, device=self.numbers.device)
        positions.requires_grad_(True)
        if self.periodic:
            cell = torch.tensor(state.getPeriodicBoxVectors(asNumpy=True).value_in_unit(unit.nanometer), dtype=torch.float32, device=self.numbers.device)/self.lengthScale
        else:
            cell = None
        if self.compiled_model is None:
            # The model can't be compiled until after it has been invoked once.
            energy = self.model(z=self.numbers, pos=positions/self.lengthScale, batch=self.batch, q=self.charge, box=cell)[0]*self.energyScale
            self.compiled_model = torch.compile(self.model, backend="inductor", dynamic=False, fullgraph=True, mode="reduce-overhead")
        else:
            try:
                energy = self.compiled_model(z=self.numbers, pos=positions/self.lengthScale, batch=self.batch, q=self.charge, box=cell)[0]*self.energyScale
            except AssertionError:
                if self.has_recompiled:
                    raise

                # Workaround for https://github.com/openmm/openmm-ml/issues/128.  Threading bugs in torch.compile can cause it to
                # incorrectly reuse cached components from earlier models.  The solution is to compile with mode="default".

                self.has_recompiled = True
                self.compiled_model = torch.compile(self.model, backend="inductor", dynamic=False, fullgraph=True, mode="default")
                energy = self.compiled_model(z=self.numbers, pos=positions/self.lengthScale, batch=self.batch, q=self.charge, box=cell)[0]*self.energyScale
        energy.backward()
        forces = (-positions.grad).detach().cpu().numpy()
        return energy, forces
