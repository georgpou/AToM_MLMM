#! python

from __future__ import print_function
from __future__ import division
import sys
import time
import os
from multiprocessing import freeze_support

def abfe_production(config_file=None, options=None):
    from atom_openmm.openmm_async_re import openmm_job_ABFE
    from atom_openmm.utils.AtomUtils import set_directory
    from pathlib import Path
    import os

    if config_file is None and options is None:
        config_file = sys.argv[1]

    assert config_file or options, "Invalid input. Specify a configuration file or options."

    print("")
    print("=======================================")
    print("AToM ABFE Asynchronous Replica Exchange")
    print("=======================================")
    print("")
    print("Started at: " + str(time.asctime()))
    if config_file:
        print("Input file:", config_file)
    elif options:
        print("Options:", options)
    print("")
    sys.stdout.flush()

    if config_file:
        with set_directory(Path(config_file).parent):
            rx = openmm_job_ABFE(
                os.path.basename(os.path.abspath(config_file)), options=None
            )
            rx.setupJob()
            rx.scheduleJobs()
    elif options:
        if "WORKDIR" in options.keys():
            with set_directory(options["WORKDIR"]):
                rx = openmm_job_ABFE(config_file, options)
                rx.setupJob()
                rx.scheduleJobs()
        else:
            rx = openmm_job_ABFE(config_file, options)
            rx.setupJob()
            rx.scheduleJobs()

if __name__ == "__main__":
    freeze_support()
    assert len(sys.argv) == 2, "Specify ONE input file"
    abfe_production(config_file = sys.argv[1])
