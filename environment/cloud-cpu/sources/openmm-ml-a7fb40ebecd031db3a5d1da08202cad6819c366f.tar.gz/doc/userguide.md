# User Guide

## Introduction

OpenMM-ML is a high level API for using machine learning interatomic potentials (MLIPs) in OpenMM simulations.  With
just a few lines of code, you can set up a simulation that uses a standard, pretrained model to represent some or all of
the interactions in a system.

OpenMM-ML does not provide the models itself.  It relies on other packages such as [MACE](https://github.com/ACEsuit/mace),
[NequIP](https://github.com/mir-group/nequip), [TorchANI](https://github.com/aiqm/torchani), and others for that.  It
provides a common interface for working with them, and handles all the details of connecting them to OpenMM.

## Installation

The stable version of OpenMM-ML can be installed with pip.

```
pip install openmmml
```

This installs only OpenMM-ML itself, not the packages that provide specific models.  Those must be installed separately
by following the instructions from the package developers.

OpenMM-ML can also be installed with conda or mamba.

```bash
mamba install -c conda-forge openmm-ml
```

However, we generally recommend using pip because most of the packages that provide models are only available
with pip, not conda.

## Usage

The central class in OpenMM-ML is `MLPotential`.  It represents an MLIP that can be used for simulations.  In the
simplest cases you just provide it the name of the pretrained potential function to use.  You can then call
`createSystem()` to create a `System` object for a simulation.  For example,

```python
from openmmml import MLPotential
potential = MLPotential('ani2x')
system = potential.createSystem(topology)
```

To use a model you provide yourself rather than a standard pretrained one, include the `modelPath` option to point to
the file containing your model.  For example,

```python
potential = MLPotential('mace', modelPath='MACE.model')
```

Other options that are specific to particular types of models are described below.

Rather than simulating the entire model with an MLIP, you can use `createMixedSystem()` to create a `System` where part
is  modeled with the MLIP and the rest is modeled with a conventional force field.  To do this, first create a `System`
that is entirely modeled with the force field.  Then call `createMixedSystem()`, providing it the list of atoms to
replace with the MLIP.

As an example, suppose the `Topology` contains three chains.  Chain 0 is a protein, chain 1 is a ligand, and chain 2 is
solvent.  The following code creates a `System` in which the internal energy of the ligand is computed with ANI2x, while
everything else (including interactions between the ligand and the rest of the system) is computed with Amber14.

```python
forcefield = ForceField('amber14-all.xml', 'amber14/tip3pfb.xml')
mm_system = forcefield.createSystem(topology)
chains = list(topology.chains())
ml_atoms = [atom.index for atom in chains[1].atoms()]
potential = MLPotential('ani2x')
ml_system = potential.createMixedSystem(topology, mm_system, ml_atoms)
```

See the API documentation for additional information about the arguments to `createSystem()`  and `createMixedSystem()`.

## Supported Models

OpenMM-ML supports models created with a number of packages.  For each one we list the supported model names (the first
argument to the `MLPotential` constructor), as well as additional arguments that can be passed to the constructor and to
`createSystem()`.

### MACE

The [MACE](https://github.com/ACEsuit/mace) package can be used to create models based on the [MACE architecture](https://arxiv.org/abs/2206.07697).
This includes both pretrained models and custom models you create yourself.  The following model names
are supported.

| Name | Model |
| --- | --- |
| `mace-off23-small`<br>`mace-off23-medium`<br>`mace-off23-large`<br>`mace-off24-medium` | Pretrained [MACE-OFF](https://pubs.acs.org/doi/10.1021/jacs.4c07099) models |
| `mace-mpa-0-medium` | Pretrained [MACE-MPA-0](https://github.com/ACEsuit/mace-foundations) model |
| `mace-omat-0-small`<br>`mace-omat-0-medium` | Pretrained [MACE-OMAT-0](https://github.com/ACEsuit/mace-foundations) models |
| `mace-omol-0-extra-large` | Pretrained MACE-OMOL-0 model |
| `mace-les-off-small` | Pretrained [MACELES-OFF](https://github.com/ChengUCB/les_fit) model (requires [LES](https://github.com/ChengUCB/les) plugin) |
| `mace-polar-1-small`<br>`mace-polar-1-medium`<br>`mace-polar-1-large` | Pretrained [MACE-POLAR-1](https://mace-docs.readthedocs.io/en/latest/guide/polar_mace.html) models (requires [`graph_longrange`](https://github.com/WillBaldwin0/graph_electrostatics)) |
| `mace` | Custom MACE models specified with the `modelPath` argument |

When creating MACE models, the following keyword arguments to the `MLPotential` constructor are supported.

| Argument | Description |
| --- | --- |
| `modelPath` | For custom models, the path to the file containing the model |

When using MACE models, the following extra keyword arguments to `createSystem()` and `createMixedSystem()` are supported.

| Argument | Description |
| --- | --- |
| `precision` | The numerical precision of the model. Supported options are `'single'` and `'double'`.  If `None`, the default precision of the model is used. |
| `returnEnergyType` | Whether to return the interaction energy or the energy including the self-energy.  The default is `'interaction_energy'`. Supported options are `'interaction_energy'` and `'energy'`. |
| `device` | The PyTorch device to perform calculations on, either a `torch.device` object or a string (such as `'cuda'` or `'cpu'`.)  If omitted, a device is chosen automatically. |
| `charge` | The total charge of the system.  If omitted, it is assumed to be 0.  This is only used by MACE-OMOL-0.  For other models it is ignored. |
| `multiplicity` | The spin multiplicity of the system.  If omitted, it is assumed to be 1.  This is only used by MACE-OMOL-0.  For other models it is ignored.  |

### AIMNet2

The [aimnet](https://github.com/isayevlab/aimnetcentral) package can be used to create models using the pretrained
[AIMNet2](https://doi.org/10.1039/D4SC08572H) potential.  This includes both the pretrained models and custom models you
create yourself.  The following pretrained model families are supported.

| Name | Model |
| --- | --- |
| `aimnet2` | General organic and elemental-organic chemistry (wB97M-D3).  Covers H, B, C, N, O, F, Si, P, S, Cl, As, Se, Br, I |
| `aimnet2-2025` | B97-3c with improved intermolecular interactions.  Same element coverage as `aimnet2` |
| `aimnet2-nse` | Open-shell systems |
| `aimnet2-pd` | Pd catalysis (B97-3c/CPCM(THF)).  Adds the Pd element (replaces As) |
| `aimnet2-rxn` | Reactive chemistry, transition states, NEB/IRC.  Limited to net-neutral systems and H, C, N, O only |
| `aimnet` | Custom AIMNet2 models specified with the `modelPath` argument |

Each pretrained family is a four-member ensemble.  Pass the `modelIndex` argument (0 through 3) to `createSystem()`
to select which member to use.  If it is omitted, member 0 is used by default.

When creating AIMNet2 models, the following keyword arguments to the `MLPotential` constructor are supported.

| Argument | Description |
| --- | --- |
| `modelPath` | For custom models (name `aimnet`), the path to the file containing the model |

When using AIMNet2 models, the following extra keyword arguments to `createSystem()` and `createMixedSystem()` are supported.

| Argument | Description |
| --- | --- |
| `charge` | The total charge of the system.  If omitted, it is assumed to be 0. |
| `multiplicity` | The spin multiplicity of the system.  If omitted, it is assumed to be 1. |
| `modelIndex` | For pretrained families, the ensemble member (0 through 3) to use.  If omitted, member 0 is used.  Not supported for custom models (name `aimnet`). |

### NequIP

The [NequIP](https://github.com/mir-group/nequip) package can be used to create models based on the [NequIP architecture](https://www.nature.com/articles/s41467-022-29939-5).
That includes models created with [Allegro](https://github.com/mir-group/allegro), which is an extension
package for NequIP.  The following model names are supported.

| Name | Model |
| --- | --- |
| `nequip` | Custom NequIP or Allegro models specified with the `modelPath` argument |

When creating NequIP models, the following keyword arguments to the `MLPotential` constructor are supported.

| Argument | Description |
| --- | --- |
| `modelPath` | The path to the checkpoint file containing the model |
| `lengthScale` | The conversion factor from the model's length units to nanometers (e.g. 0.1 if the model uses Angstroms) |
| `energyScale` | The conversion factor from the model's energy units to kJ/mol (e.g. 4.184 if the model uses kcal/mol) |

When using NequIP models, the following extra keyword arguments to `createSystem()` and `createMixedSystem()` are supported.

| Argument | Description |
| --- | --- |
| `precision` | The numerical precision of the model. Supported options are `'single'` and `'double'`.  If `None`, the default precision of the model is used. |
 | `atomTypes` | A list of integers corresponding to the NequiIP atom type for each ML atom in the system.  This is only required if the model was trained with custom atom types. If `None`, the atomic number is used to determine the atom type. This list should have the same length as the number of ML atoms in the system. |
| `device` | The PyTorch device to perform calculations on, either a `torch.device` object or a string (such as `'cuda'` or `'cpu'`.)  If omitted, a device is chosen automatically. |

### TorchANI

The [TorchANI](https://github.com/aiqm/torchani) package can be used to create models using the pretrained
[ANI-1ccx](https://www.nature.com/articles/s41467-019-10827-4) and [ANI-2x](https://pubs.acs.org/doi/full/10.1021/acs.jctc.0c00121)
potentials.

Both ANI-1ccx and ANI-2x are ensembles of eight models.  Averaging over all eight  models leads to slightly more accurate
results than any one individually.  You can optionally use only a single model, which leads to a large improvement in
speed at the cost of a small decrease in accuracy.

The following model names are supported.

| Name | Model |
| --- | --- |
| `ani1ccx` | Pretrained ANI-1ccx model |
| `ani2x` | Pretrained ANI-2x model |

When using TorchANI models, the following extra keyword arguments to `createSystem()` and `createMixedSystem()` are supported.

| Argument | Description |
| --- | --- |
| `modelIndex` | The index of the model within the ensemble to use.  If it is `None`, the full ensemble of eight models is used. |
| `device` | The PyTorch device to perform calculations on, either a `torch.device` object or a string (such as `'cuda'` or `'cpu'`.)  If omitted, a device is chosen automatically. |

### DeePMD-kit

The [DeePMD-kit](https://github.com/deepmodeling/deepmd-kit) package can be used to create models based on the
[Deep Potential](https://arxiv.org/abs/1707.01478) architecture.  The following model names are supported.

| Name | Model |
| --- | --- |
| `deepmd` | Custom models specified with the `model` argument |

When creating DeePMD-kit models, the following keyword arguments to the `MLPotential` constructor are supported.

| Argument | Description |
| --- | --- |
| `model` | The path to the file containing the model |
| `coordinatesCoefficient` | The conversion factor between the model's length units and nanometers.  The default value is 10, corresponding to DeePMD-kit's default units of Angstroms. |
| `forceCoefficient` | The conversion factor between the model's force units and kJ/mol/nm.  The default value is 964.8792534459, corresponding to DeePMD-kit's default units of eV/Å. |
| `energyCoefficient` | The conversion factor between the model's energy units and kJ/mol.  The default value is 96.48792534459, corresponding to DeePMD-kit's default units of eV. |

When using DeePMD-kit models, the following extra keyword arguments to `createSystem()` and `createMixedSystem()` are supported.

| Argument | Description |
| --- | --- |
| `lambdaName` | The name of a lambda parameter to use for alchemical calculations.  The default value is `None`, which does not create a lambda parameter. |
 | `lambdaValue` | The initial value of the lambda parameter |

### TorchMD-Net

The [TorchMD-Net](https://github.com/torchmd/torchmd-net) package can be used to create models.

Pretrained and your own local models are supported.

| Name | Model |
| ---- | ----- |
| `aceff-1.0` | Pretrained [AceFF-1.0](https://huggingface.co/Acellera/AceFF-1.0) [TensorNet](https://doi.org/10.48550/arXiv.2306.06482) model. |
| `aceff-1.1` | Pretrained [AceFF-1.1](https://huggingface.co/Acellera/AceFF-1.0) [TensorNet](https://doi.org/10.48550/arXiv.2306.06482) model. |
| `aceff-2.0` | Pretrained [AceFF-2.0](https://huggingface.co/Acellera/AceFF-2.0) [TensorNet2](https://arxiv.org/abs/2601.00581) model. |
| `torchmdnet` |  Custom TorchMD-Net models specified with the `modelPath` argument. |

When creating TorchMD-Net models, the following keyword arguments to the `MLPotential` constructor are supported.

| Argument | Description |
| --- | --- |
| `modelPath` | The path to the file containing the model. |
| `lengthScale` | The conversion factor from the model's length units to nanometers (e.g. 0.1 if the model uses Angstroms). If omitted the default is 0.1 (model in Angstroms). |
| `energyScale` | The conversion factor from the model's energy units to kJ/mol (e.g. 4.184 if the model uses kcal/mol). If omitted the default is 96.4916 (model in eV). |

When using TorchMD-Net models, the following extra keyword arguments to `createSystem()` and `createMixedSystem()` are supported.

| Argument | Description |
| --- | --- |
| `charge` | The total charge of the system.  If omitted, it is assumed to be 0. |
| `coulomb_cutoff` | The cutoff distance to apply to Coulomb interactions, in nanometers.  If omitted, it defaults to 1.2 nm.  For models without an explicit Coulomb term, this is ignored.  Whether the cutoff is actually applied depends on `useCoulombCutoff` (see below). |
| `useCoulombCutoff` | Override whether the Coulomb cutoff is applied.  If omitted, the default is determined automatically (see *Coulomb cutoff behavior* below).  Pass `True` to always apply the cutoff or `False` to disable it. |
| `remove_ref_energy` | Argument passed to the TorchMD-Net model, please see [here](https://torchmd-net.readthedocs.io/en/latest/). Default is `True`.  |
| `max_num_neighbors` | Argument passed to the TorchMD-Net model, please see [here](https://torchmd-net.readthedocs.io/en/latest/). Default is the minimum of 64 or the number of atoms in the molecule.
| `batch` | Argument passed to the forward call of the TorchMD-Net model, please see [here](https://torchmd-net.readthedocs.io/en/latest/). With this argument you can denote different atoms to be in different batches. The format should be a 1d list containing the batch index of each atom. e.g. for two molecules each with three atoms to be treated as seperate batches you would pass `batch = [0, 0, 0, 1, 1, 1]`.

#### Coulomb cutoff behaviour

The Coulomb cutoff in TorchMD-Net uses a reaction-field approximation.  Applying it to a non-periodic
system introduces errors, so by default the cutoff is only used when the system uses periodic
boundary conditions.

You can override this with the `useCoulombCutoff` argument if you know which behaviour you want:

```python
system = potential.createSystem(topology, useCoulombCutoff=False)
```

### FeNNix

OpenMM-ML has an interface to the [FeNNol](https://github.com/FeNNol-tools/FeNNol)
package for simulating [FeNNix](https://github.com/FeNNol-tools/FeNNol-PMC) models.
The following model names are supported.

| Name | Model |
| --- | --- |
| `fennix-bio1-small` | Pretrained [FeNNix-Bio1(S)](https://github.com/FeNNol-tools/FeNNol-PMC/tree/main/FENNIX-BIO1) model. |
| `fennix-bio1-medium` | Pretrained [FeNNix-Bio1(M)](https://github.com/FeNNol-tools/FeNNol-PMC/tree/main/FENNIX-BIO1) model. |
| `fennix-bio1-small-finetune-ions` | Pretrained [FeNNix-Bio1(S)](https://github.com/FeNNol-tools/FeNNol-PMC/tree/main/FENNIX-BIO1) model finetuned to AMOEBA03 ions. |
| `fennix-bio1-medium-finetune-ions` | Pretrained [FeNNix-Bio1(M)](https://github.com/FeNNol-tools/FeNNol-PMC/tree/main/FENNIX-BIO1) model finetuned to AMOEBA03 ions. |
| `fennix` | Use a custom FeNNix model loaded from a local file. |

When creating FeNNix models, the following keyword arguments to the `MLPotential` constructor are supported.

| Argument | Description |
| --- | --- |
| `modelPath` | The path to the file containing the model: required for `fennix`, ignored for all other models. |

When using FeNNix models, the following extra keyword arguments to `createSystem()` and `createMixedSystem()` are supported.

| Argument | Description |
| --- | --- |
| `charge` | The total charge of the system.  If omitted, it is assumed to be 0. |
| `precision` | `'single'` for single precision (the default if not specified) or `'double'` for double precision. |

### Orb

OpenMM-ML supports the [Orb models](https://github.com/orbital-materials/orb-models)
from Orbital Materials.  The following model names are supported.

| Name | Model |
| --- | --- |
| `orb-v3-conservative-inf-omat` | [Orb-v3](https://doi.org/10.48550/arXiv.2504.06231) model pretrained on [OMat24](https://doi.org/10.48550/arXiv.2410.12771). |
| `orb-v3-conservative-omol` | [Orb-v3](https://doi.org/10.48550/arXiv.2504.06231) model pretrained on [OMol25](https://doi.org/10.48550/arXiv.2505.08762). |

When using Orb models, the following extra keyword arguments to `createSystem()` and `createMixedSystem()` are supported.

| Argument | Description |
| --- | --- |
| `charge` | The total charge of the system.  If omitted, it is assumed to be 0. |
| `multiplicity` | The spin multiplicity of the system.  If omitted, it is assumed to be 1. |
| `device` | The PyTorch device to perform calculations on, either a `torch.device` object or a string (such as `'cuda'` or `'cpu'`.)  If omitted, a device is chosen automatically. |

### ASE

OpenMM-ML can use an arbitrary [ASE](https://ase-lib.org/) Calculator to perform calculations.  This allows it to use
any model or code for which a Calculator is available, including a wide variety of MLIPs and quantum chemistry programs.
Simply pass the [Calculator](https://docs.ase-lib.org/ase/calculators/calculators.html) to `createSystem()`.  For example,
the following uses [fairchem](https://github.com/facebookresearch/fairchem) to simulate a system with the UMA-s-1.2.1
model.

```python
from fairchem.core import pretrained_mlip, FAIRChemCalculator
predictor = pretrained_mlip.get_predict_unit("uma-s-1p2p1", device="cuda")
calculator = FAIRChemCalculator(predictor, task_name="omol")
potential = MLPotential('ase')
system = potential.createSystem(topology, calculator=calculator)
```

An ASE [Atoms](https://docs.ase-lib.org/ase/atoms.html) object is created automatically based on the OpenMM Topology.  You
can optionally provide values to add to its `info` dict.  Some Calculators use this as a mechanism to specify parameters
like total charge and spin multiplicity:

```python
system = potential.createSystem(topology, calculator=calculator, info={'charge':2})
```

In cases where you need more direct control, you can instead create an Atoms object yourself and provide it directly:

```python
system = potential.createSystem(topology, aseAtoms=atoms)
```

In this case, the Atoms should already be fully configured, including having a Calculator set.  It is up to you to make
sure the Atoms and Topology are fully consistent with each other.

The following model names are supported.

| Name | Model |
| --- | --- |
| `ase` | Custom models specified with either the `calculator` or `aseAtoms` argument |

When using ASE models, the following extra keyword arguments to `createSystem()` and `createMixedSystem()` are supported.

| Argument | Description |
| --- | --- |
| `calculator` | The Calculator to use for computations.  An Atoms object is created automatically. |
| `aseAtoms` | An Atoms object to use for computations. |
| `info` | Values that should be added to the `info` dict of the Atoms object. |

## Embeddings

For mixed ML/MM systems created with `createMixedSystem()`, the interactions within the ML subset will be computed by
the selected MLIP, and the interactions within the MM subset will be computed by the MM force field.  However, OpenMM-ML
offers various *embedding methods* that controls how the interactions between the ML and MM atoms are computed.

By default, OpenMM-ML uses mechanical embedding, but this can be selected with the `embedding` argument to
`createMixedSystem()`.  Embedding methods can either be generic methods available for use along with any MLIP (described
below), or they can be specific to certain MLIPs.  You can retrieve the names of all acceptable embedding methods (both
generic and specific) for a given MLIP by calling `MLPotential.getSupportedEmbeddings()`.  Consult the API documentation
for more information about how the embedding API works internally and how custom embedding methods can be implemented.

### Mechanical Embedding

This default embedding method can also be explicitly selected with the embedding name `mechanical`.  Mechanical
embedding uses the MM force field to compute the interactions between the ML and MM atoms.

For periodic ML/MM systems, some MLIPs may compute the interactions between ML atoms including all periodic images;
OpenMM-ML calls these models "long-range".  Other MLIPs may compute only the interactions between ML atoms in a single
periodic image.  In this case, the interaction between the ML subset and all of its other periodic images is computed
using the MM force field when using mechanical embedding.

For the pretrained models supported by OpenMM-ML, this behavior is selected automatically.  However, for custom models
(*e.g.*, the ASE, DeePMD, and NequIP interfaces, and non-pretrained FeNNix, MACE, and TorchMDNet models) it is necessary
to specify which behavior your model uses when doing mechanical embedding in a periodic system.  To do so, pass
`mlLongRange=False` to `createMixedSystem()` if your model is not long-range, and `mlLongRange=True` if it is.  An error
will be raised to inform you if this information is needed and not provided; OpenMM-ML will not assume either choice
automatically.

#### Molecules Spanning the ML-MM Region

OpenMM-ML's mechanical embedding implementation supports the link-atom method for molecules having bonds crossing the
boundary between the ML and MM regions.  If a molecule in the `Topology` provided contains bonds spanning the regions,
then the molecule will appear as is to the MM force field, but will have these bonds capped by hydrogen atoms when its
fragment(s) within the ML region are evaluated by the ML potential.

The fictitious link atoms added are implemented as virtual sites which will be inserted into the `System` and `Topology`
in use.  By default, `createMixedSystem()` only returns the `System`, but passing `returnInfo=True` returns a dictionary
instead, with keys `system` (the `System`), `topology` (a modified copy of the `Topology` with the added sites), and
`oldToNew` (a list of atom indices serving as a mapping from those in the original `Topology` to those in the modified
one).  Since they are non-physical sites added only for implementing the method, the link atoms will be added to their
own chain in the `Topology` separate from any existing chains.

Each link atom is maintained at a fixed distance along its respective bond crossing the boundary.  By default, this
distance is chosen based on the covalent radius of the atom on the ML side of the bond.  To override these distances,
pass `linkAtomDistances=[...]` to `createMixedSystem()` with a list of tuples `(atom1, atom2, distance)` for each pair
of atoms for which to use a custom distance.

Multiple link bonds from the same atom in the ML region are supported.  However, OpenMM-ML will raise an error if an ML
subset is given that would create more than one link bond to the same atom in the MM region.  Such a configuration would
place the associated link atoms too close to one another.

To avoid double-counting bonded interactions between the MM force field and ML potential, OpenMM-ML will delete:
- All MM bonds contained completely within the ML region.
- All MM angles and torsions contained completely within the ML region, but accounting for the presence of any link
  atoms and bonds leaving the region.

## Other Packages

OpenMM-ML is based on a plugin architecture, allowing other packages to provide their own interfaces to it.  The
packages listed above are the ones for which OpenMM-ML has built in support.  Other packages can provide potentials by
defining two classes that subclass `MLPotentialImpl` and `MLPotentialImplFactory`, then registering them by specifying
an [entry point](https://packaging.python.org/en/latest/specifications/entry-points/) in the group `openmmml.potentials`.
They can also provide generic embedding methods (that can be used with any potential from OpenMM-ML or any other package)
by similarly defining subclasses of `Embedding` and `EmbeddingFactory`, and registering them with an entry point in the
group `openmmml.embeddings`.  Consult the documentation for other packages to see whether they provide interfaces for
OpenMM-ML.
